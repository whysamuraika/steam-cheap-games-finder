'use strict';
/* Translations. English is the default language, Russian is optional. */
const I18N = {
  en: {
    tabSteam: '🛒 Steam Store', tabWeb: '🌐 Whole Internet',
    lblQuery: 'Title (optional)', phQuery: 'e.g. puzzle',
    lblSort: 'Sort by', sortPriceAsc: 'Cheapest first', sortReviews: 'Cheap with best reviews',
    lblMin: 'Price from', lblMax: 'Price to', phNoLimit: 'no limit',
    lblRegion: 'Price region', optRegionAuto: 'Auto (account region)',
    chkSale: 'On sale only', chkCards: 'Steam trading cards only', chkHideOwned: 'Hide already owned',
    btnFind: 'Find', btnMore: 'Show more',
    phCount: 'count', phBudget: 'budget', btnAuto: 'Auto-select cheapest',
    btnSelAll: 'Select all visible', btnClear: 'Clear',
    btnAdd: 'Add to Steam cart', btnOpenCart: 'Open cart',
    webHint: 'Compares prices in stores that sell Steam games (Steam, Humble, Fanatical, Green Man Gaming, etc.) — data from CheapShark, prices in <b>USD</b>. You buy on the store\'s own website, so instead of a cart there is an “Open selected” button.',
    lblStore: 'Store', optAllStores: 'All stores',
    lblMinUsd: 'Price from, $', lblMaxUsd: 'Price to, $',
    lblRating: 'Steam reviews from, %', phRating: 'e.g. 80',
    chkSteamworks: 'Steam-redeemable only',
    sortSavings: 'Biggest discount', sortRating: 'Best deal rating', sortReviewsWeb: 'Best Steam reviews',
    phBudgetUsd: 'budget, $', btnOpenSel: 'Open selected in stores',
    ownedLoading: 'Checking your library…',
    ownedOk: 'Your library: {n} items — they will be marked',
    ownedNone: '⚠ Can\'t see your library. Log in to Steam at store.steampowered.com in this browser and reload this page.',
    ownedErr: '⚠ Couldn\'t load your library: {m}',
    untitled: '(untitled)', ownedBadge: '✔ already in your library', webOwnedBadge: '✔ already in your Steam library',
    loading: 'Loading…', searchErr: 'Search error: {m}',
    statusShown: 'Shown: {v} (loaded {l}, total in store for this filter: {t})',
    wStatusShown: 'Shown: {v} (loaded {l})',
    totalSel: 'Selected: {n} · Total: {sum}',
    autoNeed: 'Enter a count and/or a budget for auto-select',
    nothingSel: 'Nothing selected',
    noSession: 'No sessionid cookie — open store.steampowered.com and log in',
    logFail: '✗ {title}: {m} (add manually: {url})',
    logDone: 'Done: added {ok} of {n}. Check your cart.',
    errPage: 'game page: HTTP {s}',
    errAge: 'age-check page — open the game once manually and confirm your age',
    errNoSubid: 'couldn\'t find subid (the game may be unavailable in your region)',
    confirmTabs: 'Open {n} tabs?'
  },
  ru: {
    tabSteam: '🛒 Магазин Steam', tabWeb: '🌐 Весь интернет',
    lblQuery: 'Название (необязательно)', phQuery: 'например: puzzle',
    lblSort: 'Сортировка', sortPriceAsc: 'Сначала самые дешёвые', sortReviews: 'Дешёвые с лучшими отзывами',
    lblMin: 'Цена от', lblMax: 'Цена до', phNoLimit: 'без лимита',
    lblRegion: 'Регион цен', optRegionAuto: 'Авто (как в аккаунте)',
    chkSale: 'Только со скидкой', chkCards: 'Только с карточками Steam', chkHideOwned: 'Скрыть уже купленные',
    btnFind: 'Найти', btnMore: 'Показать ещё',
    phCount: 'кол-во', phBudget: 'бюджет', btnAuto: 'Авто-выбор самых дешёвых',
    btnSelAll: 'Выбрать все видимые', btnClear: 'Сбросить',
    btnAdd: 'Добавить в корзину Steam', btnOpenCart: 'Открыть корзину',
    webHint: 'Сравнение цен в магазинах, продающих игры для Steam (Steam, Humble, Fanatical, Green Man Gaming и др.) — данные CheapShark, цены в <b>USD</b>. Покупка происходит на сайте магазина, поэтому вместо корзины — кнопка «Открыть выбранные».',
    lblStore: 'Магазин', optAllStores: 'Все магазины',
    lblMinUsd: 'Цена от, $', lblMaxUsd: 'Цена до, $',
    lblRating: 'Отзывы Steam от, %', phRating: 'напр. 80',
    chkSteamworks: 'Только для активации в Steam',
    sortSavings: 'Самая большая скидка', sortRating: 'Лучшие по рейтингу сделки', sortReviewsWeb: 'Лучшие отзывы Steam',
    phBudgetUsd: 'бюджет, $', btnOpenSel: 'Открыть выбранные в магазинах',
    ownedLoading: 'Проверяю вашу библиотеку…',
    ownedOk: 'Ваша библиотека: {n} игр/приложений — они будут помечены',
    ownedNone: '⚠ Не вижу вашу библиотеку. Войдите в Steam на store.steampowered.com в этом браузере и обновите страницу.',
    ownedErr: '⚠ Не удалось получить библиотеку: {m}',
    untitled: '(без названия)', ownedBadge: '✔ уже в библиотеке', webOwnedBadge: '✔ уже в библиотеке Steam',
    loading: 'Загружаю…', searchErr: 'Ошибка поиска: {m}',
    statusShown: 'Показано: {v} (загружено {l}, всего по фильтру в магазине: {t})',
    wStatusShown: 'Показано: {v} (загружено {l})',
    totalSel: 'Выбрано: {n} · Итого: {sum}',
    autoNeed: 'Укажите количество и/или бюджет для авто-выбора',
    nothingSel: 'Ничего не выбрано',
    noSession: 'Нет cookie sessionid — откройте store.steampowered.com и войдите в аккаунт',
    logFail: '✗ {title}: {m} (можно добавить вручную: {url})',
    logDone: 'Готово: добавлено {ok} из {n}. Проверьте корзину.',
    errPage: 'страница игры: HTTP {s}',
    errAge: 'страница с проверкой возраста — откройте игру вручную один раз и подтвердите возраст',
    errNoSubid: 'не нашёл subid (возможно, игра недоступна для покупки в вашем регионе)',
    confirmTabs: 'Открыть {n} вкладок?'
  }
};

let LANG = 'en';
try { const s = localStorage.getItem('scf_lang'); if (s === 'ru' || s === 'en') LANG = s; } catch { }

function t(key, p) {
  let s = (I18N[LANG] && I18N[LANG][key]) ?? I18N.en[key] ?? key;
  if (p) for (const k in p) s = s.split('{' + k + '}').join(p[k]);
  return s;
}

const langHooks = [];
function applyI18n() {
  document.documentElement.lang = LANG;
  document.querySelectorAll('[data-i18n]').forEach(e => { e.textContent = t(e.dataset.i18n); });
  document.querySelectorAll('[data-i18n-ph]').forEach(e => { e.placeholder = t(e.dataset.i18nPh); });
  document.querySelectorAll('[data-i18n-html]').forEach(e => { e.innerHTML = t(e.dataset.i18nHtml); });
  document.querySelector('#lang').value = LANG;
}
document.querySelector('#lang').addEventListener('change', e => {
  LANG = e.target.value;
  try { localStorage.setItem('scf_lang', LANG); } catch { }
  applyI18n();
  langHooks.forEach(f => f());
});
applyI18n();
