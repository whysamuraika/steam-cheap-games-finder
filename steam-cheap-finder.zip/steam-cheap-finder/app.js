'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const PAGE = 50;
const S = {
  items: new Map(), order: [], seen: new Set(), selected: new Set(),
  start: 0, total: 0, done: false, loading: false, fmt: null,
  owned: { apps: new Set(), pkgs: new Set() }
};
let ownedState = { type: 'loading' };

/* ---------- helpers ---------- */
function log(msg, cls = '') {
  const d = document.createElement('div');
  d.className = cls; d.textContent = msg;
  $('#log').prepend(d);
}
const num = id => { const v = parseFloat(String($(id).value).replace(',', '.')); return isNaN(v) ? null : v; };
const steamLang = () => (LANG === 'ru' ? 'russian' : 'english');

function parseFmt(txt) {
  const m = txt.match(/^(\D*?)(\d[\d\s.,\u00a0]*)(\D*)$/);
  if (!m) return null;
  const n = m[2].trim();
  const hasDec = /[.,]\d{2}$/.test(n);
  return { pre: m[1], suf: m[3], dec: hasDec ? n[n.length - 3] : null };
}
function money(cents) {
  const f = S.fmt || { pre: '', suf: '', dec: '.' };
  const s = f.dec ? (cents / 100).toFixed(2).replace('.', f.dec) : String(Math.round(cents / 100));
  return f.pre + s + f.suf;
}

/* ---------- settings ---------- */
const SAVE = ['q', 'sort', 'min', 'max', 'cc'];
const SAVE_CHK = ['onlySale', 'cards', 'hideOwned'];
function loadSettings() {
  try {
    const s = JSON.parse(localStorage.getItem('scf') || '{}');
    SAVE.forEach(k => { if (s[k] !== undefined) $('#' + k).value = s[k]; });
    SAVE_CHK.forEach(k => { if (s[k] !== undefined) $('#' + k).checked = s[k]; });
  } catch { }
}
function saveSettings() {
  const s = {};
  SAVE.forEach(k => s[k] = $('#' + k).value);
  SAVE_CHK.forEach(k => s[k] = $('#' + k).checked);
  try { localStorage.setItem('scf', JSON.stringify(s)); } catch { }
}

/* ---------- user library ---------- */
function renderOwnedInfo() {
  const o = ownedState;
  $('#ownedInfo').textContent =
    o.type === 'ok' ? t('ownedOk', { n: o.n }) :
    o.type === 'none' ? t('ownedNone') :
    o.type === 'err' ? t('ownedErr', { m: o.m }) : t('ownedLoading');
}
async function loadOwned() {
  try {
    const r = await fetch('https://store.steampowered.com/dynamicstore/userdata/?t=' + Date.now(), { credentials: 'include' });
    const j = await r.json();
    S.owned.apps = new Set((j.rgOwnedApps || []).map(Number));
    S.owned.pkgs = new Set((j.rgOwnedPackages || []).map(Number));
    ownedState = S.owned.apps.size ? { type: 'ok', n: S.owned.apps.size } : { type: 'none' };
  } catch (e) {
    ownedState = { type: 'err', m: e.message };
  }
  renderOwnedInfo();
}
const isOwned = it => it.ownedFlag || it.appids.some(a => S.owned.apps.has(a)) || (it.pkg && S.owned.pkgs.has(it.pkg));

/* ---------- search ---------- */
function buildUrl(start) {
  const p = new URLSearchParams({
    query: $('#q').value.trim(), start, count: PAGE, sort_by: $('#sort').value,
    category1: 998, hidef2p: 1, infinite: 1, l: steamLang()
  });
  const max = num('#max'); if (max) p.set('maxprice', Math.ceil(max));
  if ($('#onlySale').checked) p.set('specials', 1);
  if ($('#cards').checked) p.set('category2', 29); // Steam Trading Cards
  const cc = $('#cc').value; if (cc) p.set('cc', cc);
  return 'https://store.steampowered.com/search/results/?' + p;
}

async function fetchPage(start) {
  const r = await fetch(buildUrl(start), { credentials: 'include' });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const j = await r.json();
  const doc = new DOMParser().parseFromString(j.results_html || '', 'text/html');
  const rows = [...doc.querySelectorAll('a.search_result_row')];
  const items = [];
  for (const a of rows) {
    if (a.dataset.dsBundleid) continue;
    const cents = Number(a.querySelector('.search_price_discount_combined')?.dataset.priceFinal);
    if (!cents) continue; // free / no price
    const appids = (a.dataset.dsAppid || '').split(',').map(Number).filter(Boolean);
    const pkg = Number(a.dataset.dsPackageid) || null;
    const key = pkg ? 'p' + pkg : 'a' + appids[0];
    const finalText = a.querySelector('.discount_final_price')?.textContent.trim() || '';
    if (!S.fmt && finalText) S.fmt = parseFmt(finalText);
    items.push({
      key, appids, pkg, cents, finalText,
      title: a.querySelector('.title')?.textContent.trim() || t('untitled'),
      img: a.querySelector('.search_capsule img')?.src || '',
      pct: a.querySelector('.discount_pct')?.textContent.trim() || '',
      orig: a.querySelector('.discount_original_price')?.textContent.trim() || '',
      review: (a.querySelector('.search_review_summary')?.dataset.tooltipHtml || '').replace(/<br\s*\/?>/gi, ' · '),
      ownedFlag: a.classList.contains('ds_owned'),
      url: a.href
    });
  }
  return { items, total: j.total_count || 0, raw: rows.length };
}

function visible() {
  const hide = $('#hideOwned').checked;
  const minC = Math.round((num('#min') || 0) * 100);
  const maxC = Math.round((num('#max') || 0) * 100);
  return S.order.map(k => S.items.get(k)).filter(it =>
    !(hide && isOwned(it)) && it.cents >= minC && (!maxC || it.cents <= maxC));
}

async function search(reset) {
  if (S.loading) return;
  S.loading = true; $('#go').disabled = true; $('#more').disabled = true;
  try {
    if (reset) { S.order = []; S.seen = new Set(); S.start = 0; S.done = false; S.total = 0; }
    const before = visible().length;
    let pages = 0;
    while (!S.done && visible().length - before < PAGE && pages < 10) {
      setStatus(t('loading'));
      const { items, total, raw } = await fetchPage(S.start);
      pages++; S.start += PAGE; S.total = total;
      for (const it of items) {
        if (S.seen.has(it.key)) continue;
        S.seen.add(it.key); S.items.set(it.key, it); S.order.push(it.key);
      }
      if (raw === 0 || S.start >= total) S.done = true;
    }
    render();
  } catch (e) {
    setStatus(t('searchErr', { m: e.message }));
  } finally {
    S.loading = false; $('#go').disabled = false; $('#more').disabled = false;
  }
}

/* ---------- rendering ---------- */
function setStatus(txt) { $('#status').textContent = txt; }

function cardHtml(it) {
  const owned = isOwned(it), sel = S.selected.has(it.key);
  return `<label class="card${sel ? ' sel' : ''}${owned ? ' owned' : ''}" data-key="${esc(it.key)}">
    <input type="checkbox" ${sel ? 'checked' : ''} ${owned ? 'disabled' : ''}>
    <img src="${esc(it.img)}" alt="">
    <div class="info">
      <a class="t" href="${esc(it.url)}" target="_blank" title="${esc(it.title)}">${esc(it.title)}</a>
      <div class="rv">${esc(it.review)}</div>
      ${owned ? `<div class="badge">${esc(t('ownedBadge'))}</div>` : ''}
    </div>
    <div class="price">
      ${it.pct ? `<span class="pct">${esc(it.pct)}</span><span class="orig">${esc(it.orig)}</span><br>` : ''}
      <span class="fin">${esc(it.finalText)}</span>
    </div>
  </label>`;
}

function render() {
  const vis = visible();
  $('#list').innerHTML = vis.map(cardHtml).join('');
  setStatus(t('statusShown', { v: vis.length, l: S.order.length, t: S.total }));
  $('#more').hidden = S.done;
  updateTotal();
}

function updateTotal() {
  let sum = 0, n = 0;
  for (const k of S.selected) { const it = S.items.get(k); if (it) { sum += it.cents; n++; } }
  $('#sel').textContent = t('totalSel', { n, sum: n ? money(sum) : '—' });
}

/* ---------- selection ---------- */
$('#list').addEventListener('change', e => {
  const card = e.target.closest('.card'); if (!card) return;
  const key = card.dataset.key;
  if (e.target.checked) S.selected.add(key); else S.selected.delete(key);
  card.classList.toggle('sel', e.target.checked);
  updateTotal();
});

$('#selAll').onclick = () => { visible().filter(i => !isOwned(i)).forEach(i => S.selected.add(i.key)); render(); };
$('#clear').onclick = () => { S.selected.clear(); render(); };
$('#autoBtn').onclick = () => {
  const n = parseInt($('#autoN').value) || Infinity;
  const b = num('#budget'); const bc = b ? Math.round(b * 100) : Infinity;
  if (n === Infinity && bc === Infinity) { log(t('autoNeed'), 'err'); return; }
  S.selected.clear();
  let sum = 0, c = 0;
  for (const it of visible().filter(i => !isOwned(i)).sort((a, b) => a.cents - b.cents)) {
    if (c >= n || sum + it.cents > bc) break;
    S.selected.add(it.key); sum += it.cents; c++;
  }
  render();
};

/* ---------- cart ---------- */
async function findSubid(it) {
  const appid = it.appids[0];
  // 1) appdetails (may return null — that's fine, fall through)
  try {
    const r = await fetch(`https://store.steampowered.com/api/appdetails?appids=${appid}&filters=basic,package_groups`, { credentials: 'include' });
    const j = await r.json().catch(() => null);
    const d = j && j[appid];
    const subs = d && d.success && d.data ? (d.data.package_groups || []).flatMap(g => g.subs || []) : [];
    if (subs.length) return subs[0].packageid;
  } catch { }
  // 2) parse the store page
  const r = await fetch(`https://store.steampowered.com/app/${appid}/?l=english`, { credentials: 'include' });
  if (!r.ok) throw new Error(t('errPage', { s: r.status }));
  const html = await r.text();
  const m = html.match(/name=["']subid["'][^>]*value=["'](\d+)/i)
    || html.match(/add_to_cart_(\d+)/)
    || html.match(/addToCart\(\s*(\d+)/i);
  if (m) return Number(m[1]);
  if (/agecheck|agegate/i.test(r.url + html.slice(0, 5000))) throw new Error(t('errAge'));
  throw new Error(t('errNoSubid'));
}

async function addToCart() {
  const sel = [...S.selected].map(k => S.items.get(k)).filter(Boolean);
  if (!sel.length) { log(t('nothingSel'), 'err'); return; }
  const c = await chrome.cookies.get({ url: 'https://store.steampowered.com/', name: 'sessionid' });
  if (!c) { log(t('noSession'), 'err'); return; }
  $('#addBtn').disabled = true;
  let ok = 0;
  for (const it of sel) {
    try {
      const subid = it.pkg || await findSubid(it);
      const body = new URLSearchParams({ action: 'add_to_cart', sessionid: c.value, subid: String(subid) });
      const r = await fetch('https://store.steampowered.com/cart/', {
        method: 'POST', credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body
      });
      if (!r.ok) throw new Error('HTTP ' + r.status);
      ok++; log(`✓ ${it.title}`, 'ok');
    } catch (e) {
      log(t('logFail', { title: it.title, m: e.message, url: it.url }), 'err');
    }
    await new Promise(r => setTimeout(r, 400));
  }
  log(t('logDone', { ok, n: sel.length }), ok ? 'ok' : 'err');
  $('#addBtn').disabled = false;
}

$('#addBtn').onclick = addToCart;
$('#openCart').onclick = () => chrome.tabs.create({ url: 'https://store.steampowered.com/cart/' });

/* ---------- startup ---------- */
$('#go').onclick = () => { saveSettings(); search(true); };
$('#more').onclick = () => search(false);
$('#hideOwned').onchange = () => { saveSettings(); render(); };
$('#min').addEventListener('change', () => { saveSettings(); render(); });
document.querySelector('#viewSteam').addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox') $('#go').click();
});

// Language switch: refresh texts, and reload results so titles/reviews come in the new language.
langHooks.push(() => {
  renderOwnedInfo();
  if (S.order.length) search(true); else render();
});

(async () => {
  loadSettings();
  renderOwnedInfo();
  updateTotal();
  await loadOwned();
  search(true);
})();
