'use strict';
/* Вкладка «Весь интернет» — сравнение цен через CheapShark */
const W = {
  items: new Map(), order: [], seen: new Set(), selected: new Set(),
  page: 0, done: false, loading: false, started: false, stores: new Map()
};
const WPAGE = 60;
const SITE = 'https://www.cheapshark.com';
const usd = c => '$' + (c / 100).toFixed(2);
const SORTS = {
  price: { sortBy: 'Price' },
  savings: { sortBy: 'Savings', desc: 1 },
  rating: { sortBy: 'Deal Rating' },
  reviews: { sortBy: 'Reviews', desc: 1 }
};

/* ---- вкладки ---- */
document.querySelectorAll('.tab').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b === btn));
  ['viewSteam', 'viewWeb'].forEach(id => { $('#' + id).hidden = id !== btn.dataset.view; });
  if (btn.dataset.view === 'viewWeb' && !W.started) { W.started = true; initWeb(); }
  if (btn.dataset.view === 'viewWeb') wRender();
}));

async function initWeb() {
  try {
    const j = await (await fetch(SITE + '/api/1.0/stores')).json();
    j.filter(s => String(s.isActive) === '1').forEach(s => {
      W.stores.set(String(s.storeID), { name: s.storeName, icon: SITE + (s.images?.icon || '') });
      $('#wstore').add(new Option(s.storeName, s.storeID));
    });
  } catch { }
  wSearch(true);
}

/* ---- поиск ---- */
function wUrl(page) {
  const sort = SORTS[$('#wsort').value] || SORTS.price;
  const p = new URLSearchParams({ pageSize: WPAGE, pageNumber: page, sortBy: sort.sortBy });
  if (sort.desc) p.set('desc', 1);
  const q = $('#wq').value.trim(); if (q) p.set('title', q);
  const st = $('#wstore').value; if (st) p.set('storeID', st);
  const min = num('#wmin'); if (min !== null) p.set('lowerPrice', min);
  const max = num('#wmax'); if (max) p.set('upperPrice', max);
  const rt = num('#wrating'); if (rt) p.set('steamRating', rt);
  if ($('#wSteamworks').checked) p.set('steamworks', 1);
  if ($('#wSale').checked) p.set('onSale', 1);
  return SITE + '/api/1.0/deals?' + p;
}

async function wFetch(page) {
  const r = await fetch(wUrl(page));
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const arr = await r.json();
  const byGame = $('#wsort').value === 'price';
  const items = [];
  for (const d of arr) {
    const cents = Math.round(parseFloat(d.salePrice) * 100);
    if (!cents) continue;
    const savings = Math.round(parseFloat(d.savings) || 0);
    items.push({
      key: byGame ? 'g' + d.gameID : 'd' + d.dealID,
      cents, savings,
      normal: Math.round(parseFloat(d.normalPrice) * 100),
      title: d.title, img: d.thumb || '',
      appid: Number(d.steamAppID) || null,
      storeID: String(d.storeID),
      rating: d.steamRatingText ? `${d.steamRatingText} (${d.steamRatingPercent}%)` : '',
      meta: d.metacriticScore && d.metacriticScore !== '0' ? `Metacritic ${d.metacriticScore}` : '',
      url: SITE + '/redirect?dealID=' + d.dealID
    });
  }
  return { items, count: arr.length };
}

const wOwned = it => !!(it.appid && S.owned.apps.has(it.appid));
const wVisible = () => {
  const hide = $('#wHideOwned').checked;
  return W.order.map(k => W.items.get(k)).filter(it => !(hide && wOwned(it)));
};

async function wSearch(reset) {
  if (W.loading) return;
  W.loading = true; $('#wgo').disabled = true; $('#wmore').disabled = true;
  try {
    if (reset) { W.order = []; W.seen = new Set(); W.page = 0; W.done = false; }
    const before = wVisible().length;
    let pages = 0;
    while (!W.done && wVisible().length - before < WPAGE && pages < 5) {
      $('#wstatus').textContent = 'Загружаю…';
      const { items, count } = await wFetch(W.page);
      pages++; W.page++;
      for (const it of items) {
        if (W.seen.has(it.key)) continue;
        W.seen.add(it.key); W.items.set(it.key, it); W.order.push(it.key);
      }
      if (count < WPAGE) W.done = true;
    }
    wRender();
  } catch (e) {
    $('#wstatus').textContent = 'Ошибка поиска: ' + e.message;
  } finally {
    W.loading = false; $('#wgo').disabled = false; $('#wmore').disabled = false;
  }
}

/* ---- отображение ---- */
function wCard(it) {
  const owned = wOwned(it), sel = W.selected.has(it.key);
  const st = W.stores.get(it.storeID);
  const info = [it.rating, it.meta].filter(Boolean).map(esc).join(' · ');
  return `<label class="card${sel ? ' sel' : ''}${owned ? ' owned' : ''}" data-key="${esc(it.key)}">
    <input type="checkbox" ${sel ? 'checked' : ''} ${owned ? 'disabled' : ''}>
    <img src="${esc(it.img)}" alt="">
    <div class="info">
      <a class="t" href="${esc(it.url)}" target="_blank" title="${esc(it.title)}">${esc(it.title)}</a>
      <div class="rv">${st ? `<img src="${esc(st.icon)}" alt=""><span class="store">${esc(st.name)}</span>` : ''}${info}</div>
      ${owned ? '<div class="badge">✔ уже в библиотеке Steam</div>' : ''}
    </div>
    <div class="price">
      ${it.savings >= 1 ? `<span class="pct">-${it.savings}%</span><span class="orig">${usd(it.normal)}</span><br>` : ''}
      <span class="fin">${usd(it.cents)}</span>
    </div>
  </label>`;
}

function wRender() {
  const vis = wVisible();
  $('#wlist').innerHTML = vis.map(wCard).join('');
  $('#wstatus').textContent = `Показано: ${vis.length} (загружено ${W.order.length})`;
  $('#wmore').hidden = W.done;
  wTotal();
}
function wTotal() {
  let sum = 0, n = 0;
  for (const k of W.selected) { const it = W.items.get(k); if (it) { sum += it.cents; n++; } }
  $('#wsel').textContent = `Выбрано: ${n} · Итого: ${n ? usd(sum) : '—'}`;
}

/* ---- выбор и действия ---- */
$('#wlist').addEventListener('change', e => {
  const card = e.target.closest('.card'); if (!card) return;
  const key = card.dataset.key;
  if (e.target.checked) W.selected.add(key); else W.selected.delete(key);
  card.classList.toggle('sel', e.target.checked);
  wTotal();
});
$('#wselAll').onclick = () => { wVisible().filter(i => !wOwned(i)).forEach(i => W.selected.add(i.key)); wRender(); };
$('#wclear').onclick = () => { W.selected.clear(); wRender(); };
$('#wautoBtn').onclick = () => {
  const n = parseInt($('#wautoN').value) || Infinity;
  const b = num('#wbudget'); const bc = b ? Math.round(b * 100) : Infinity;
  if (n === Infinity && bc === Infinity) { $('#wstatus').textContent = 'Укажите количество и/или бюджет для авто-выбора'; return; }
  W.selected.clear();
  let sum = 0, c = 0;
  for (const it of wVisible().filter(i => !wOwned(i)).sort((a, b) => a.cents - b.cents)) {
    if (c >= n || sum + it.cents > bc) break;
    W.selected.add(it.key); sum += it.cents; c++;
  }
  wRender();
};
$('#wopen').onclick = () => {
  const sel = [...W.selected].map(k => W.items.get(k)).filter(Boolean);
  if (!sel.length) { $('#wstatus').textContent = 'Ничего не выбрано'; return; }
  if (sel.length > 8 && !confirm(`Открыть ${sel.length} вкладок?`)) return;
  sel.forEach(it => chrome.tabs.create({ url: it.url, active: false }));
};

$('#wgo').onclick = () => wSearch(true);
$('#wmore').onclick = () => wSearch(false);
$('#wHideOwned').onchange = wRender;
document.querySelector('#viewWeb').addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox') $('#wgo').click();
});
